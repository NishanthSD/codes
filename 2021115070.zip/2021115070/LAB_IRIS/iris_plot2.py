import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
iris = load_iris()
plt.figure(figsize=(8, 6))
for i, species_name in enumerate(iris.target_names):
    species_data = iris.data[iris.target == i]
    plt.scatter(species_data[:, 0], species_data[:, 1], label=species_name)
plt.xlabel('Sepal length (cm)')
plt.ylabel('Sepal width (cm)')
plt.title('Iris dataset: Sepal length vs Sepal width')
plt.legend()
plt.show()
