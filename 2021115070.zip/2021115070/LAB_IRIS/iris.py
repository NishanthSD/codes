from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import numpy as np
from knn_classifier import *

iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
labels = []
for i in range(len(np.unique(y_train))):
    points.append(X_train[y_train == i])
    labels.append(i)
test_point = [5.1, 3.5, 1.4, 0.2]
k = 5
predicted_label = knn(points, labels, test_point, k)
print(f"Predicted label: {predicted_label}")
print("Test Set Data:")
for data_point, label in zip(X_test, y_test):
    print(f"Data Point: {data_point}, Label: {label}")