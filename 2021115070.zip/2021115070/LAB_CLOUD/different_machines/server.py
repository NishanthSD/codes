import socket as s
import threading as th
def rcv(sck):
    while True:
        st = sck.recv(1024).decode()
        print(st)

def snd(sck):
    while True:
        st = input()
        sck.send(st.encode())

sck = s.socket(s.AF_INET,s.SOCK_STREAM)
sck.bind(("10.11.145.137",3300))
sck.listen(2)
print("Waiting for clients....")
sk,addr = sck.accept()
print("CONNECTED : ",addr)
t1 = th.Thread(target=rcv,args=(sk,))
t2 = th.Thread(target=snd,args=(sk,))

t1.start()
t2.start()

t1.join()
t2.join()

