import socket
import struct

MULTICAST_ADDR = '224.0.0.1'
PORT = 10000

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('', PORT))

ttl = struct.pack('b', 1)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)

message = b'Hello, multicast!'
sock.sendto(message, (MULTICAST_ADDR, PORT))
