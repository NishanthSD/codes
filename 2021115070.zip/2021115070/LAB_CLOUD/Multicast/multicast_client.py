import socket
import struct

MULTICAST_ADDR = '224.0.0.1'
PORT = 10000
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
ttl = struct.pack('b', 1)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)
sock.bind((MULTICAST_ADDR, PORT))
group = socket.inet_aton(MULTICAST_ADDR)
mreq = struct.pack('4sL', group, socket.INADDR_ANY)
sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
while True:
    print("Waiting to receive...")
    data, address = sock.recvfrom(1024)
    print(f"Received {len(data)} bytes from {address}: {data.decode('utf-8')}")
