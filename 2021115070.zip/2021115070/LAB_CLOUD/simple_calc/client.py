import socket as s
import threading as th

def rcv(sck):
    while True:
        st = sck.recv(1024).decode()
        print(st)

def snd(sck):
    while True:
        st = input()
        sck.send(st.encode())

sck = s.socket(s.AF_INET,s.SOCK_STREAM)

sck.connect(("127.0.0.1",3015))

t1 = th.Thread(target=rcv,args=(sck,))
t2 = th.Thread(target=snd,args=(sck,))

t1.start()
t2.start()

t1.join()
t2.join()

