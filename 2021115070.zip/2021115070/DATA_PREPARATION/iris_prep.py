import pandas as pd

iris = pd.read_csv("diabetes.csv")
f = open('t.txt','w')

f.write(iris.describe().to_string())
f.close()