import seaborn as sns

def find_outliers(column):
    print(column.head())
    Q1 = column.quantile(0.25)
    Q3 = column.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    ret = []
    print(upper_bound, lower_bound)
    for i in column.to_numpy():
        if i > upper_bound or i < lower_bound:
            ret += [i]
    return ret

iris = sns.load_dataset("iris")
print(iris.head())
print("\nMeasure of Central Tendency:")
print(iris.describe())
print(iris["species"].unique())
setosa_petals = iris[iris["species"] == "setosa"]["petal_length"]
virginica_petals = iris[iris["species"] == "virginica"]["petal_length"]
versicolor_petals = iris[iris["species"] == "versicolor"]["petal_length"]
sp = find_outliers(setosa_petals)
vp = find_outliers(virginica_petals)
vrp = find_outliers(versicolor_petals)
print("\nOutliers in Sepal Length in setosa:")
print(sp)
print("\nOutliers in Sepal Length in virginica:")
print(vp)
print("\nOutliers in Sepal Length in versicolor:")
print(vrp)
